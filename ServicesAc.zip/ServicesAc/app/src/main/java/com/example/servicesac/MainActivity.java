package com.example.servicesac;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements LifecycleObserver {
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this,"ksndf",Toast.LENGTH_LONG).show();
        Intent broadcast=new Intent(this,BootComplete.class);
        sendBroadcast(broadcast);
    }


    private Button bt,stop;

    @Override
    protected void onStop() {
        super.onStop();
        Intent broadcast=new Intent(this,BootComplete.class);
        sendBroadcast(broadcast);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt=findViewById(R.id.button);
        stop=findViewById(R.id.button2);
        if(!checkSystemWritePermission());


        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri uri=Uri.parse("android.resource://"+getPackageName()+"/raw/talk_dirty");
                RingtoneManager.setActualDefaultRingtoneUri(MainActivity.this,RingtoneManager.TYPE_ALARM,uri);
                RingtoneManager.setActualDefaultRingtoneUri(MainActivity.this,RingtoneManager.TYPE_RINGTONE,uri);

               // startService(new Intent(MainActivity.this,BackgroundServices.class));
                Log.i("buttonstart","dsfj");
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this,BackgroundServices.class));
            }
        });
    }
    private boolean checkSystemWritePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(Settings.System.canWrite(this))
                return true;
            else
                openAndroidPermissionsMenu();
        }
        return false;
    }

    private void openAndroidPermissionsMenu() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }
}
