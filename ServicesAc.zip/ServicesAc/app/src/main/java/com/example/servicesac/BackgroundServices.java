package com.example.servicesac;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;


public class BackgroundServices extends Service {



    MediaPlayer player;
    Handler delayhandler = new Handler();
    Runnable run = new Runnable() {
        @Override
        public void run() {
            loop();

        }
    };

    @Override
    public void onTaskRemoved(Intent rootIntent) {

        super.onTaskRemoved(rootIntent);
        //here you will get call when app close.
        Intent broadcast=new Intent(this,BootComplete.class);
        sendBroadcast(broadcast);
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        Intent broadcast=new Intent(this,BootComplete.class);
        sendBroadcast(broadcast);

    }

    void loop(){

        AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 100, 0);
        delayhandler.postDelayed(run, 2000);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        player=MediaPlayer.create(this,R.raw.femaleorgasmsound);
        player.setLooping(true);
        //AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
       // audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 100, 0);
        player.start();

      //  delayhandler.postDelayed(run, 2000);

        Log.i("isStarted: ","runn");


        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
